/* John Anthony Kazos Jr. - < jakj@j-a-k-j.com > */

All artwork pulled from other sources is licenced under various open-community licenses and is attributed and redistributed inside the texture directories.

All original work by me in this project is licensed under the WTFPL.

http://www.wtfpl.net/

The full license text is located below.

The following are ENCOURAGED (that means just do it and tell me afterward; don't bother asking first):

*) Usage of this mod both publicly and privately.
*) Distribution of this mod in both public and private modpacks.
*) Usage of this mod on servers both public and private.
*) Alteration and modification of this mod.
*) Linking to and discussing this mod elsewhere on the Internet.
*) The production of videos (such as Let's Plays and Spotlights) including this mod.
*) Everything else.

The following are DISCOURAGED:

[This space intentionally left blank.]

The following are PROHIBITED:

Claiming this work as your own without first changing its name to make it clear your changes are your own and not mine.

BEGIN LICENSE:
=============

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.

/* This program is free software. It comes without any warranty, to
     * the extent permitted by applicable law. You can redistribute it
     * and/or modify it under the terms of the Do What The Fuck You Want
     * To Public License, Version 2, as published by Sam Hocevar. See
     * http://www.wtfpl.net/ for more details. */

http://www.wtfpl.net/faq/

END LICENSE
