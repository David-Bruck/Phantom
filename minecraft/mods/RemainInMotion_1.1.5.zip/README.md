RemainInMotion
==============

Continuation of JAKJ's excellent block-moving mod. I plan to update and expand mod integration and create a functional hardcore mode, and port everything to new Minecraft versions.

Pre-compiled binaries are available at the following URL: https://www.mediafire.com/folder/nx48d9udpfpln/RemainInMotion

(The name is a pun on Newton's first law - a Redstone in Motion tends to Remain in Motion.)
