package me.planetguy.remaininmotion ;

public enum PacketTypes
{
	Render ,
	MultipartPropagation ;
}
